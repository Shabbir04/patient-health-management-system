import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/EditPatientServlet")
public class EditPatientServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// Get the form data
		int id = Integer.parseInt(request.getParameter("id"));
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		String phone = request.getParameter("phone");
		String dob = request.getParameter("dob");
		String gender = request.getParameter("gender");
		String address = request.getParameter("address");
		String medicalHistory = request.getParameter("medicalHistory");

		// Update the patient information in the database
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			// Connect to the database
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/esd", "root", "0188");
			// Prepare the SQL statement to update the patient
			pstmt = conn.prepareStatement(
					"UPDATE patients SET name=?, email=?, phone=?, dob=?, gender=?, address=?, medical_history=? WHERE id=?");
			pstmt.setString(1, name);
			pstmt.setString(2, email);
			pstmt.setString(3, phone);
			pstmt.setString(4, dob);
			pstmt.setString(5, gender);
			pstmt.setString(6, address);
			pstmt.setString(7, medicalHistory);
			pstmt.setInt(8, id);
			// Execute the SQL statement
			pstmt.executeUpdate();
			// Redirect to the patient's details page
			response.sendRedirect("staff.jsp");
		} catch (SQLException | ClassNotFoundException e) {
			// Handle errors
			e.printStackTrace();
			response.getWriter().println("Error: " + e.getMessage());
		} finally {
			// Close the database resources
			try {
				if (pstmt != null) {
					pstmt.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
