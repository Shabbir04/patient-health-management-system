import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    // JDBC driver and database URL
    static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost:3306/esd";
    
    // Database credentials
    static final String USER = "root";
    static final String PASS = "0188";
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            // Get form parameters
            String username = request.getParameter("username");
            String password = request.getParameter("password");
            String userType = request.getParameter("role");
            
            // Create connection and prepared statement
            Connection conn = null;
            PreparedStatement stmt = null;
            
            try {
                // Register JDBC driver
                Class.forName(JDBC_DRIVER);

                // Open a connection
                conn = DriverManager.getConnection(DB_URL, USER, PASS);

                // Prepare SQL query
                String sql = "SELECT * FROM users WHERE username = ? AND password = ? AND role = ?";
                stmt = conn.prepareStatement(sql);
                stmt.setString(1, username);
                stmt.setString(2, password);
                stmt.setString(3, userType);

                // Execute the query
                ResultSet rs = stmt.executeQuery();

                // Check if user exists
                if (rs.next()) {
                    // User exists, redirect to appropriate page
                    String redirectURL = "";
                    switch (userType) {
                        case "doctor":
                            redirectURL = "doctor.jsp";
                            break;
                        case "staff":
                            redirectURL = "staff.jsp";
                            break;
                        case "patient":
                            redirectURL = "patient.jsp";
                            break;
                        default:
                            out.println("Invalid user type!");
                            return;
                    }
                    response.sendRedirect(redirectURL);
                } else {
                    // User doesn't exist, show error message
                    out.println("Invalid username or password!");
                }
            } catch (ClassNotFoundException | SQLException e) {
                out.println("Error: " + e.getMessage());
            } finally {
                // Close connection and statement
                try {
                    if (stmt != null) {
                        stmt.close();
                    }
                    if (conn != null) {
                        conn.close();
                    }
                } catch (SQLException e) {
                    out.println("Error: " + e.getMessage());
                }
            }
        }
    }
}
